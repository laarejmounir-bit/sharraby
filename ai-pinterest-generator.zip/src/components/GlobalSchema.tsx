export default function GlobalSchema() {
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": "https://sharraby.me/#organization",
    name: "شرّابي Sharrabi",
    url: "https://sharraby.me",
    logo: {
      "@type": "ImageObject",
      "@id": "https://sharraby.me/#logo",
      url: "https://sharraby.me/logo.png",
      caption: "شرّابي Sharrabi"
    },
    image: {
      "@id": "https://sharraby.me/#logo"
    },
    description: "المتجر الأول في السعودية لشراء جوارب وشرابات مريحة، قطنية، وضد الروائح. تسوق أفضل شرابات نانو الفضة وجوارب القطن المريحة الآن.",
    email: "contact@sharraby.com",
    telephone: "+966531002083",
    address: {
      "@type": "PostalAddress",
      addressLocality: "الرياض",
      addressRegion: "الرياض",
      addressCountry: "SA"
    },
    contactPoint: {
      "@type": "ContactPoint",
      telephone: "+966531002083",
      contactType: "customer service",
      areaServed: "SA",
      availableLanguage: ["Arabic", "English"],
      email: "contact@sharraby.com"
    },
    sameAs: [
      "https://www.instagram.com/sharraby_sa",
      "https://twitter.com/sharraby_sa",
      "https://www.tiktok.com/@sharraby_sa"
    ]
  };

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": "https://sharraby.me/#website",
    url: "https://sharraby.me",
    name: "شرّابي Sharrabi",
    description: "المتجر الأول في السعودية لشراء جوارب وشرابات مريحة، قطنية، وضد الروائح.",
    publisher: {
      "@id": "https://sharraby.me/#organization"
    },
    potentialAction: {
      "@type": "SearchAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: "https://sharraby.me/search?q={search_term_string}"
      },
      "query-input": "required name=search_term_string"
    },
    inLanguage: "ar-SA"
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [organizationSchema, websiteSchema]
        })
      }}
    />
  );
}
