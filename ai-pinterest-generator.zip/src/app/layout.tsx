import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import Script from "next/script";
import GlobalSchema from "@/components/GlobalSchema";

const cairo = Cairo({
  subsets: ["arabic"],
  variable: "--font-cairo",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const viewport: Viewport = {
  themeColor: "#059669",
};

export const metadata: Metadata = {
  metadataBase: new URL("https://sharraby.me"),
  title: {
    default: "شرّابي | Sharrabi - متجر الجوارب والشرابات الفاخرة",
    template: "%s | شرّابي Sharrabi",
  },
  description: "المتجر الأول في السعودية لشراء جوارب وشرابات مريحة، قطنية، وضد الروائح. تسوق أفضل شرابات نانو الفضة وجوارب القطن المريحة الآن.",
  keywords: ["شرابات", "جوارب", "شرابات نانو الفضة", "جوارب نانو الفضة", "شرابات ضد الروائح", "جوارب ضد الروائح", "شرابات قطن", "جوارب مريحة", "السعودية"],
  authors: [{ name: "شرّابي Sharrabi" }],
  creator: "شرّابي Sharrabi",
  openGraph: {
    type: "website",
    locale: "ar_SA",
    url: "https://sharraby.me",
    title: "شرّابي | Sharrabi - متجر الجوارب والشرابات الفاخرة",
    description: "اكتشف تشكيلتنا الواسعة من جوارب وشرابات مريحة ومانعة للتعرق. جودة عالية مصممة خصيصاً لأجواء السعودية.",
    siteName: "شرّابي | Sharrabi",
    images: [
      {
        url: "/nano-black.jpeg",
        width: 1200,
        height: 630,
        alt: "شرّابي - جوارب وشرابات فاخرة",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "شرّابي | Sharrabi - الجوارب والشرابات الفاخرة",
    description: "تسوق أفضل شرابات وجوارب نانو الفضة والقطن المريحة في السعودية.",
    creator: "@sharrabi",
    images: ["/nano-black.jpeg"],
  },
  alternates: {
    canonical: "/",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <head>
        <GlobalSchema />
      </head>
      <body className="antialiased bg-[#F8F9FA] text-[#1D1D1F] font-sans flex flex-col min-h-screen print:bg-white">
        <div className="print:hidden">
          <Navbar />
        </div>
        <main className="flex-1 mt-16 md:mt-20 print:mt-0 print:p-0">{children}</main>
        <div className="print:hidden">
          <CartDrawer />
          <Footer />
        </div>
      </body>
    </html>
  );
}
