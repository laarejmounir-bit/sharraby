import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "إتمام الطلب - شرّابي | Sharrabi",
  robots: {
    index: false,
    follow: false,
  },
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
